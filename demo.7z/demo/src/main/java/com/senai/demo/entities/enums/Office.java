package com.senai.demo.entities.enums;

public enum Office {
    SALE, VETERINARY, SUPPORT;
    
}
