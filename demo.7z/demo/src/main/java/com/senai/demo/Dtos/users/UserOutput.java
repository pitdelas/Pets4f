package com.senai.demo.Dtos.users;

import com.senai.demo.entities.enums.UserStatus;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data

public class UserOutput {
    private Long id;
    private String userName;
    private String firstName;
    private String lastName;
    private UserStatus userStatus;
}
