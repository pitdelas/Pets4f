package com.senai.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.demo.entities.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {
    
}
