package com.senai.demo.Dtos.users;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor 
@Data

public class Userinput {
    private Long id;
    private String userName;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String phone;
    
}
