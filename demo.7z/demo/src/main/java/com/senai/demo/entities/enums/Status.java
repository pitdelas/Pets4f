package com.senai.demo.entities.enums;

public enum Status {
    AVAILABLE, PENDING, SOLD;

}
