package com.senai.demo.entities;

import com.senai.demo.entities.enums.Office;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
@Entity @EqualsAndHashCode(callSuper = false)
public class Adiministrador extends User {
    private Boolean isAdmin;
    @Enumerated(EnumType.STRING)
    private Office office;
    
}
