package com.senai.demo.entities.enums;

public enum OrderStatus {
    PLACED, APROVED, DELIVERED;
    
}
