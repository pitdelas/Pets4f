package com.senai.demo.entities.enums;

public enum UserStatus {
    ACTIVE, DEACTIVE;
    
}
