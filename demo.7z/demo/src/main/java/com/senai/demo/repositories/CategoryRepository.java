package com.senai.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.demo.entities.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    
}
